package egovframework.pf.rpt.service.impl;

import java.util.List;
import java.util.Map;

import egovframework.pf.cmmn.service.SearchVO;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

import org.apache.ibatis.session.SqlSessionFactory;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;



/**
 * 통계분석 매퍼 클래스
 *
 * @author  이재성
 * @since 2024.04.16
 * @version 1.0
 * @see <pre>
 *  == 개정이력(Modification Information) ==
 *
 * @         수정일            		       수정자           			수정내용
 * @    ----------------    ------------    ---------------------------
 * @       2024.04.16          	이재성         			최초 생성
 *
 * </pre>
 */
@Mapper("analysisMapper")
public interface AnalysisMapper {

	// 수입실적
	List<?> selectAnalysis1List(SearchVO vo)throws Exception;
	// 수입실적 차트
	List<?> selectAnalysis1Chart(SearchVO vo)throws Exception;
	// 수출실적
	List<?> selectAnalysis2List(SearchVO vo)throws Exception;
	// 수출실적 차트
	List<?> selectAnalysis2Chart(SearchVO vo)throws Exception;
	// 해외거래처별 수입실적
	List<?> selectAnalysis3List(SearchVO vo)throws Exception;
	// 해외거래처별 수출실적
	List<?> selectAnalysis4List(SearchVO vo)throws Exception;
	// 운임 비교
	List<?> selectAnalysis5List(SearchVO vo)throws Exception;
	// 운임 비교 서브 리스트
	List<?> selectAnalysis5SubList(SearchVO vo)throws Exception; 
	// 보험료 비교
	List<?> selectAnalysis6List(SearchVO vo)throws Exception;
	// 보험료 비교 서브 리스트
	List<?> selectAnalysis6SubList(SearchVO vo)throws Exception; 
	// 외환신고대상 수출
	List<?> selectAnalysis7List(SearchVO vo)throws Exception;
	// 수입물품 단가비교
	List<?> selectCost1List(SearchVO vo)throws Exception;
	// 수입물푼 단가비교 차트
	List<?> selectCost1Chart(SearchVO vo) throws Exception;
	// 유무상 수입건 과세가격 비교
	List<?> selectCost2List(SearchVO vo)throws Exception;
	// 유무상 수입건 과세가격 비교 차트
	List<?> selectCost2Chart(SearchVO vo)throws Exception;
	// 동일거래, 결제통화 변경점검
	List<?> selectCost3List(SearchVO vo)throws Exception;
	// 동일자재코드 품목분류 상이점검
	List<?> selectEtc1List(SearchVO vo)throws Exception;
	// 감면
	List<?> selectEtc2List(SearchVO vo)throws Exception;
	// FTA 적정성(직접운송원칙)
	List<?> selectEtc3List(SearchVO vo)throws Exception;
	// FTA 적용누락
	List<?> selectEtc4List(SearchVO vo)throws Exception;
}