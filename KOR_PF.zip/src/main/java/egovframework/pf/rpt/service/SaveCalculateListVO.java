package egovframework.pf.rpt.service;

import java.util.List;

/**
 * @Class Name : SaveImportVO.java
 * @Description : SaveImportVO Class
 * @Modification Information
 * @
 * @  수정일                    수정자              수정내용
 * @ ---------     ---------   -------------------------------
 * @ 2024.01.29      서인석              최초생성
 *
 * @author 서인석
 * @since 2024.01.29
 * @version 1.0
 * @see
 *
 *  Copyright (C) by KORDSYSTEMS All right reserved.
 */
public class SaveCalculateListVO {

	private List<SaveCalculateVO> dbArray;
	
	private List<SaveCalCodeVO> calCode;
	
	private List<List<String>> dbArrayList;
	

	
	public List<SaveCalculateVO> getDbArray() {
		return dbArray;
	}
	public void setDbArray(List<SaveCalculateVO> dbArray) {
		this.dbArray = dbArray;
	}
	public List<List<String>> getDbArrayList() {
		return dbArrayList;
	}
	public void setDbArrayList(List<List<String>> dbArrayList) {
		this.dbArrayList = dbArrayList;
	}
	public List<SaveCalCodeVO> getCalCode() {
		return calCode;
	}
	public void setCalCode(List<SaveCalCodeVO> calCode) {
		this.calCode = calCode;
	}

}