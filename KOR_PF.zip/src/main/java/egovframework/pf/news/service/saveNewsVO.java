package egovframework.pf.news.service;

public class saveNewsVO {

	private String source;
	private String newsSeq;
	private String titleKr;
	private String cnKr;
	private String fileName;
    
    private String regDt;
    private String regId;
    private String edtDt;
    private String edtId;
    
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getNewsSeq() {
		return newsSeq;
	}
	public void setNewsSeq(String newsSeq) {
		this.newsSeq = newsSeq;
	}
	public String getTitleKr() {
		return titleKr;
	}
	public void setTitleKr(String titleKr) {
		this.titleKr = titleKr;
	}
	public String getCnKr() {
		return cnKr;
	}
	public void setCnKr(String cnKr) {
		this.cnKr = cnKr;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getEdtDt() {
		return edtDt;
	}
	public void setEdtDt(String edtDt) {
		this.edtDt = edtDt;
	}
	public String getEdtId() {
		return edtId;
	}
	public void setEdtId(String edtId) {
		this.edtId = edtId;
	}
    
}
