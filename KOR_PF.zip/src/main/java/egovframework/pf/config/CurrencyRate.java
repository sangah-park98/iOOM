package egovframework.pf.config;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class CurrencyRate {
	
//	private List<JasperListVo> listData = null;
    private String currencyPair;
    private Date date;
    private BigDecimal askPrice;
    private BigDecimal bidPrice;

    public String getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = currencyPair;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public BigDecimal getAskPrice() {
        return askPrice;
    }

    public void setAskPrice(BigDecimal askPrice) {
        this.askPrice = askPrice;
    }

    public BigDecimal getBidPrice() {
        return bidPrice;
    }

    public void setBidPrice(BigDecimal bidPrice) {
        this.bidPrice = bidPrice;
    }

//	public List<JasperListVo> getListData() {
//		return listData;
//	}
//
//	public void setListData(List<JasperListVo> listData) {
//		this.listData = listData;
//	}
}
