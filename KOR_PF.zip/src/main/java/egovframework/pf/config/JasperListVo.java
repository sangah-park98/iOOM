package egovframework.pf.config;

public class JasperListVo {
	private String itemNum;
	private String numOfPckg;
	private String goods;
	private String originCrtrn;
	private String grossWght;
	private String invoices;
		
	public String getItemNum() {
		return itemNum;
	}
	public void setItemNum(String itemNum) {
		this.itemNum = itemNum;
	}
	public String getNumOfPckg() {
		return numOfPckg;
	}
	public void setNumOfPckg(String numOfPckg) {
		this.numOfPckg = numOfPckg;
	}
	public String getGoods() {
		return goods;
	}
	public void setGoods(String goods) {
		this.goods = goods;
	}
	public String getOriginCrtrn() {
		return originCrtrn;
	}
	public void setOriginCrtrn(String originCrtrn) {
		this.originCrtrn = originCrtrn;
	}
	public String getGrossWght() {
		return grossWght;
	}
	public void setGrossWght(String grossWght) {
		this.grossWght = grossWght;
	}
	public String getInvoices() {
		return invoices;
	}
	public void setInvoices(String invoices) {
		this.invoices = invoices;
	}
	
	
}
