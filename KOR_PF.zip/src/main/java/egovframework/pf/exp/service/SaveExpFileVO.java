package egovframework.pf.exp.service;

import org.springframework.web.multipart.MultipartFile;

public class SaveExpFileVO {

	private MultipartFile file;
	private String exportInNo;
	private String rptNo;
	private String orgFileName;
    private String name;
    private String bl;
    private String packingList;
    private String fileName;
    private String invoiceNo;
    private String uploadDt;
    private String regDt;
    private String regId;
    private String cmpnyCd;
    private String certifiOrgin;
    private String requirement;
    private String accounts;
    
	public String getCertifiOrgin() {
		return certifiOrgin;
	}
	public void setCertifiOrgin(String certifiOrgin) {
		this.certifiOrgin = certifiOrgin;
	}
	public String getRequirement() {
		return requirement;
	}
	public void setRequirement(String requirement) {
		this.requirement = requirement;
	}
	public String getCmpnyCd() {
		return cmpnyCd;
	}
	public void setCmpnyCd(String cmpnyCd) {
		this.cmpnyCd = cmpnyCd;
	}
	public String getAccounts() {
		return accounts;
	}
	public void setAccounts(String accounts) {
		this.accounts = accounts;
	}
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	public String getExportInNo() {
		return exportInNo;
	}
	public void setExportInNo(String exportInNo) {
		this.exportInNo = exportInNo;
	}
	public String getRptNo() {
		return rptNo;
	}
	public void setRptNo(String rptNo) {
		this.rptNo = rptNo;
	}
	public String getOrgFileName() {
		return orgFileName;
	}
	public void setOrgFileName(String orgFileName) {
		this.orgFileName = orgFileName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBl() {
		return bl;
	}
	public void setBl(String bl) {
		this.bl = bl;
	}
	public String getPackingList() {
		return packingList;
	}
	public void setPackingList(String packingList) {
		this.packingList = packingList;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public String getUploadDt() {
		return uploadDt;
	}
	public void setUploadDt(String uploadDt) {
		this.uploadDt = uploadDt;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
}
