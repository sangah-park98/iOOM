package egovframework.pf.exp.service;

import org.springframework.web.bind.annotation.RequestParam;

public class SaveCoEnrollVO {

	private String seq;
	private String rptNo;
	private String invoiceNo;
	private String state;
	private String corpNo;
	private String cmpnyNm;
	private String billCmpnyNm;
	private String mangerNm;
	private String billManagerNm;
	private String managerEmail;
	private String billManagerEmail;
	private String managerNum;
	private String fileNm;
	private String fileOrgNm;
	private String billCorpNo;
	private String cmpnyName; //등록된 사업자번호 -> 회사이름
	private String invoiceRptNo;
	
	
	private String delYn;
	private String regDt;
	private String regId;
	private String edtDt;
	private String edtId;
	
	
	
	public String getInvoiceRptNo() {
		return invoiceRptNo;
	}
	public void setInvoiceRptNo(String invoiceRptNo) {
		this.invoiceRptNo = invoiceRptNo;
	}
	public String getCmpnyName() {
		return cmpnyName;
	}
	public void setCmpnyName(String cmpnyName) {
		this.cmpnyName = cmpnyName;
	}
	public String getBillCorpNo() {
		return billCorpNo;
	}
	public void setBillCorpNo(String billCorpNo) {
		this.billCorpNo = billCorpNo;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getRptNo() {
		return rptNo;
	}
	public void setRptNo(String rptNo) {
		this.rptNo = rptNo;
	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCorpNo() {
		return corpNo;
	}
	public void setCorpNo(String corpNo) {
		this.corpNo = corpNo;
	}
	public String getCmpnyNm() {
		return cmpnyNm;
	}
	public void setCmpnyNm(String cmpnyNm) {
		this.cmpnyNm = cmpnyNm;
	}
	public String getBillCmpnyNm() {
		return billCmpnyNm;
	}
	public void setBillCmpnyNm(String billCmpnyNm) {
		this.billCmpnyNm = billCmpnyNm;
	}
	public String getMangerNm() {
		return mangerNm;
	}
	public void setMangerNm(String mangerNm) {
		this.mangerNm = mangerNm;
	}
	public String getBillManagerNm() {
		return billManagerNm;
	}
	public void setBillManagerNm(String billManagerNm) {
		this.billManagerNm = billManagerNm;
	}
	public String getManagerEmail() {
		return managerEmail;
	}
	public void setManagerEmail(String managerEmail) {
		this.managerEmail = managerEmail;
	}
	public String getBillManagerEmail() {
		return billManagerEmail;
	}
	public void setBillManagerEmail(String billManagerEmail) {
		this.billManagerEmail = billManagerEmail;
	}
	public String getManagerNum() {
		return managerNum;
	}
	public void setManagerNum(String managerNum) {
		this.managerNum = managerNum;
	}
	public String getFileNm() {
		return fileNm;
	}
	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}
	public String getFileOrgNm() {
		return fileOrgNm;
	}
	public void setFileOrgNm(String fileOrgNm) {
		this.fileOrgNm = fileOrgNm;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getEdtDt() {
		return edtDt;
	}
	public void setEdtDt(String edtDt) {
		this.edtDt = edtDt;
	}
	public String getEdtId() {
		return edtId;
	}
	public void setEdtId(String edtId) {
		this.edtId = edtId;
	}
	
}