package egovframework.pf.exp.service;


public class SaveExportCoVO {

	private String coDate; //co요청일자
	private String coName;	//요청자
	private String state;	//상태
	private String subNum;	//제출번호
	private String invoiceNo;	//인보이스번호
	private String rptNo;	//수출신고번호
	private String lisDay;	//수리일자
	private String producer;	//생산자
	private String importCountry;	//수입국
	private String importer;	//수입자
	private String impgname;	//품명
	private String qty;	//수량
	private String ut;	//단위
	private String amt;	//금액
	private String concod; //인코텀즈
	private String hscode;	//hscode
	private String deterOrigin;	//원산지결정기준
	private String freeName;	//자유무역협정명칭
	private String issueNo;	//발급번호
	private String issueDate;	//발급일자
	private String coFile;	//원산지증명서
	private String coFileOrg;	
	private String summitFile;	
	private String summitFileOrg;	//제출서류
	private String issuanceCost;	//발행비용
	private String judgmentCost;	//판정비용
	private String tableType;
	private String taxNo;
	private String seq;
	private String request;
	
	private String delYn;
	private String regDt;
	private String regId;
	private String edtDt;
	private String edtId;
	
	
	
	public String getRequest() {
		return request;
	}
	public void setRequest(String request) {
		this.request = request;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getTaxNo() {
		return taxNo;
	}
	public void setTaxNo(String taxNo) {
		this.taxNo = taxNo;
	}
	public String getTableType() {
		return tableType;
	}
	public void setTableType(String tableType) {
		this.tableType = tableType;
	}
	public String getCoDate() {
		return coDate;
	}
	public void setCoDate(String coDate) {
		this.coDate = coDate;
	}
	public String getCoName() {
		return coName;
	}
	public void setCoName(String coName) {
		this.coName = coName;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getSubNum() {
		return subNum;
	}
	public void setSubNum(String subNum) {
		this.subNum = subNum;
	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public String getRptNo() {
		return rptNo;
	}
	public void setRptNo(String rptNo) {
		this.rptNo = rptNo;
	}
	public String getLisDay() {
		return lisDay;
	}
	public void setLisDay(String lisDay) {
		this.lisDay = lisDay;
	}
	public String getProducer() {
		return producer;
	}
	public void setProducer(String producer) {
		this.producer = producer;
	}
	public String getImportCountry() {
		return importCountry;
	}
	public void setImportCountry(String importCountry) {
		this.importCountry = importCountry;
	}
	public String getImporter() {
		return importer;
	}
	public void setImporter(String importer) {
		this.importer = importer;
	}
	public String getImpgname() {
		return impgname;
	}
	public void setImpgname(String impgname) {
		this.impgname = impgname;
	}
	public String getQty() {
		return qty;
	}
	public void setQty(String qty) {
		this.qty = qty;
	}
	public String getUt() {
		return ut;
	}
	public void setUt(String ut) {
		this.ut = ut;
	}
	public String getAmt() {
		return amt;
	}
	public void setAmt(String amt) {
		this.amt = amt;
	}
	public String getConcod() {
		return concod;
	}
	public void setConcod(String concod) {
		this.concod = concod;
	}
	public String getHscode() {
		return hscode;
	}
	public void setHscode(String hscode) {
		this.hscode = hscode;
	}
	public String getDeterOrigin() {
		return deterOrigin;
	}
	public void setDeterOrigin(String deterOrigin) {
		this.deterOrigin = deterOrigin;
	}
	public String getFreeName() {
		return freeName;
	}
	public void setFreeName(String freeName) {
		this.freeName = freeName;
	}
	public String getIssueNo() {
		return issueNo;
	}
	public void setIssueNo(String issueNo) {
		this.issueNo = issueNo;
	}
	public String getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}
	public String getCoFile() {
		return coFile;
	}
	public void setCoFile(String coFile) {
		this.coFile = coFile;
	}
	public String getCoFileOrg() {
		return coFileOrg;
	}
	public void setCoFileOrg(String coFileOrg) {
		this.coFileOrg = coFileOrg;
	}
	public String getSummitFile() {
		return summitFile;
	}
	public void setSummitFile(String summitFile) {
		this.summitFile = summitFile;
	}
	public String getSummitFileOrg() {
		return summitFileOrg;
	}
	public void setSummitFileOrg(String summitFileOrg) {
		this.summitFileOrg = summitFileOrg;
	}
	public String getIssuanceCost() {
		return issuanceCost;
	}
	public void setIssuanceCost(String issuanceCost) {
		this.issuanceCost = issuanceCost;
	}
	public String getJudgmentCost() {
		return judgmentCost;
	}
	public void setJudgmentCost(String judgmentCost) {
		this.judgmentCost = judgmentCost;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getEdtDt() {
		return edtDt;
	}
	public void setEdtDt(String edtDt) {
		this.edtDt = edtDt;
	}
	public String getEdtId() {
		return edtId;
	}
	public void setEdtId(String edtId) {
		this.edtId = edtId;
	}
	
}