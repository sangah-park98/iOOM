package egovframework.pf.exp.service;

public class SaveExpMainVO {
	
	private String cmpnyCd;
	private String corpNo;
	private String shipper;			//화주
	private String address;	    
	private String consigneeAddress;	    
	private String invoiceNo;	    //인보이스번호
	private String invoiceDate;		//인보이스 날짜
    private String invoiceTo;		
    private String consignee;		//수취인
    private String loadPort;		//선적항
    private String plLoadPort;		//선적항
    private String flight;			//선박,비행
    private String plFlight;			//선박,비행

	private String payment;			//지불
    private String trade;			//거래 조건
    private String freight;			//화물
    private String freightCurrency;			
    private String insurance;		//보험
    private String insuranceCurrency;		
    private String depDate;			//출발 날짜
    private String plDepDate;			//출발 날짜
    private String destination;		//최종 목적지
    private String plDestination;		//최종 목적지
    private String manufact;
    
    private String mainIndex;
    private String itemCode;			
	private String hsCode;				//hscode
	private String itemName;			//일반품목명
    private String goodDes;				//품목설명
    private String nation;				//원산지
	private String quantity;			
    private String uom;					
    private String unitPrice;			//가격단위
    private String currency;			//통화단위
    private String amount;				//양
    private String total;				//총합계
    private String totalPrice;			//총가격
    private String totalAmount;	
    private String comments;	
    private String plComments;	
    
    // -----------------------
    private String ctNo;	
    private String plHsCode;	
    private String plItemName;	
    private String plGoodDes;	
    private String plNation;	
    private String plQuantity;	
    private String plUom;	
    private String net;	
    private String gross;	
    private String kg;	
    private String totalQuantity;		
    private String totalNet;			
    private String totalGross;			
    private String totalKg;		
    private String totalPlCnt;		
    
    private String regDt;
    private String regId;
    private String edtDt;
    private String edtId;
    
	public String getCmpnyCd() {
		return cmpnyCd;
	}
	public void setCmpnyCd(String cmpnyCd) {
		this.cmpnyCd = cmpnyCd;
	}
	public String getCorpNo() {
		return corpNo;
	}
	public void setCorpNo(String corpNo) {
		this.corpNo = corpNo;
	}
	public String getPlComments() {
		return plComments;
	}
	public void setPlComments(String plComments) {
		this.plComments = plComments;
	}
	public String getConsigneeAddress() {
		return consigneeAddress;
	}
	public void setConsigneeAddress(String consigneeAddress) {
		this.consigneeAddress = consigneeAddress;
	}
	public String getFreightCurrency() {
		return freightCurrency;
	}
	public void setFreightCurrency(String freightCurrency) {
		this.freightCurrency = freightCurrency;
	}
	public String getInsuranceCurrency() {
		return insuranceCurrency;
	}
	public void setInsuranceCurrency(String insuranceCurrency) {
		this.insuranceCurrency = insuranceCurrency;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getTotalPlCnt() {
		return totalPlCnt;
	}
	public void setTotalPlCnt(String totalPlCnt) {
		this.totalPlCnt = totalPlCnt;
	}
	public String getPlLoadPort() {
		return plLoadPort;
	}
	public void setPlLoadPort(String plLoadPort) {
		this.plLoadPort = plLoadPort;
	}
	public String getPlFlight() {
		return plFlight;
	}
	public void setPlFlight(String plFlight) {
		this.plFlight = plFlight;
	}
	public String getPlDepDate() {
		return plDepDate;
	}
	public void setPlDepDate(String plDepDate) {
		this.plDepDate = plDepDate;
	}
	public String getPlDestination() {
		return plDestination;
	}
	public void setPlDestination(String plDestination) {
		this.plDestination = plDestination;
	}
	public String getCtNo() {
		return ctNo;
	}
	public void setCtNo(String ctNo) {
		this.ctNo = ctNo;
	}
	public String getPlHsCode() {
		return plHsCode;
	}
	public void setPlHsCode(String plHsCode) {
		this.plHsCode = plHsCode;
	}
	public String getPlItemName() {
		return plItemName;
	}
	public void setPlItemName(String plItemName) {
		this.plItemName = plItemName;
	}
	public String getPlGoodDes() {
		return plGoodDes;
	}
	public void setPlGoodDes(String plGoodDes) {
		this.plGoodDes = plGoodDes;
	}
	public String getPlNation() {
		return plNation;
	}
	public void setPlNation(String plNation) {
		this.plNation = plNation;
	}
	public String getPlQuantity() {
		return plQuantity;
	}
	public void setPlQuantity(String plQuantity) {
		this.plQuantity = plQuantity;
	}
	public String getPlUom() {
		return plUom;
	}
	public void setPlUom(String plUom) {
		this.plUom = plUom;
	}
	public String getNet() {
		return net;
	}
	public void setNet(String net) {
		this.net = net;
	}
	public String getGross() {
		return gross;
	}
	public void setGross(String gross) {
		this.gross = gross;
	}
	public String getKg() {
		return kg;
	}
	public void setKg(String kg) {
		this.kg = kg;
	}
	public String getShipper() {
		return shipper;
	}
	public void setShipper(String shipper) {
		this.shipper = shipper;
	}
    public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public String getInvoiceTo() {
		return invoiceTo;
	}
	public void setInvoiceTo(String invoiceTo) {
		this.invoiceTo = invoiceTo;
	}
	public String getConsignee() {
		return consignee;
	}
	public void setConsignee(String consignee) {
		this.consignee = consignee;
	}
	public String getLoadPort() {
		return loadPort;
	}
	public void setLoadPort(String loadPort) {
		this.loadPort = loadPort;
	}
	public String getFlight() {
		return flight;
	}
	public void setFlight(String flight) {
		this.flight = flight;
	}
	public String getPayment() {
		return payment;
	}
	public void setPayment(String payment) {
		this.payment = payment;
	}
	public String getTrade() {
		return trade;
	}
	public void setTrade(String trade) {
		this.trade = trade;
	}
	public String getFreight() {
		return freight;
	}
	public void setFreight(String freight) {
		this.freight = freight;
	}
	public String getInsurance() {
		return insurance;
	}
	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}
	public String getDepDate() {
		return depDate;
	}
	public void setDepDate(String depDate) {
		this.depDate = depDate;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getManufact() {
		return manufact;
	}
	public void setManufact(String manufact) {
		this.manufact = manufact;
	}
	public String getMainIndex() {
		return mainIndex;
	}
	public void setMainIndex(String mainIndex) {
		this.mainIndex = mainIndex;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getHsCode() {
		return hsCode;
	}
	public void setHsCode(String hsCode) {
		this.hsCode = hsCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getGoodDes() {
		return goodDes;
	}
	public void setGoodDes(String goodDes) {
		this.goodDes = goodDes;
	}
	public String getNation() {
		return nation;
	}
	public void setNation(String nation) {
		this.nation = nation;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	public String getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(String totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getEdtDt() {
		return edtDt;
	}
	public void setEdtDt(String edtDt) {
		this.edtDt = edtDt;
	}
	public String getEdtId() {
		return edtId;
	}
	public void setEdtId(String edtId) {
		this.edtId = edtId;
	}
	public String getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(String totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	public String getTotalNet() {
		return totalNet;
	}
	public void setTotalNet(String totalNet) {
		this.totalNet = totalNet;
	}
	public String getTotalGross() {
		return totalGross;
	}
	public void setTotalGross(String totalGross) {
		this.totalGross = totalGross;
	}
	public String getTotalKg() {
		return totalKg;
	}
	public void setTotalKg(String totalKg) {
		this.totalKg = totalKg;
	}
}
