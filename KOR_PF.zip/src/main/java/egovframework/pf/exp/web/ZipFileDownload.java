package egovframework.pf.exp.web;

public class ZipFileDownload {
	
	private String mainCd;
	private String invoiceNo;
	private String ciNo;
	private String blno;
	private String docuType;
	private String docuOrgFile;
	private String docuFile;
	private String docuRptNo;
	private String docuPath;
	private String uploadDt;
	private String rptNo;
	
	
	
	public String getMainCd() {
		return mainCd;
	}
	public void setMainCd(String mainCd) {
		this.mainCd = mainCd;
	}
	public String getCiNo() {
		return ciNo;
	}
	public void setCiNo(String ciNo) {
		this.ciNo = ciNo;
	}
	public String getUploadDt() {
		return uploadDt;
	}
	public void setUploadDt(String uploadDt) {
		this.uploadDt = uploadDt;
	}
	public String getDocuPath() {
		return docuPath;
	}
	public void setDocuPath(String docuPath) {
		this.docuPath = docuPath;
	}
	public String getRptNo() {
		return rptNo;
	}
	public void setRptNo(String rptNo) {
		this.rptNo = rptNo;
	}
	public ZipFileDownload() {}

    public ZipFileDownload(String docuRptNo) {
        this.docuRptNo = docuRptNo;
    }
	public String getDocuRptNo() {
		return docuRptNo;
	}
	public void setDocuRptNo(String docuRptNo) {
		this.docuRptNo = docuRptNo;
	}
	public String getBlno() {
		return blno;
	}
	public void setBlno(String blno) {
		this.blno = blno;
	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public String getDocuType() {
		return docuType;
	}
	public void setDocuType(String docuType) {
		this.docuType = docuType;
	}
	public String getDocuOrgFile() {
		return docuOrgFile;
	}
	public void setDocuOrgFile(String docuOrgFile) {
		this.docuOrgFile = docuOrgFile;
	}
	public String getDocuFile() {
		return docuFile;
	}
	public void setDocuFile(String docuFile) {
		this.docuFile = docuFile;
	}
	 
}
