package egovframework.pf.member.sevice;


/**
 * @Class Name : SaveMemberVO.java
 * @Description : SaveMemberVO Class
 * @Modification Information
 * @
 * @  수정일                    수정자              수정내용
 * @ ---------     ---------   -------------------------------
 * @ 2024.01.17      권예지              최초생성
 *
 * @author 권예지
 * @since 2024.01.17
 * @version 1.0
 * @see
 *
 *  Copyright (C) by MOPAS All right reserved.
 */
public class SaveMemberVO {

	/*검색 구분*/
	private String searchTp;
	private String CdTp;
	/*사용자정보*/
	private String MEMBER_LANG;
	private String MEMBER_NAME;
	private String MEMBER_ID;
	private String MEMBER_PASSWORD;
    private String MEMBER_PASS;
    private String MEMBER_CURRENTPWD;
    private String MEMBER_EMAIL;
    private String MEMBER_TEL;
    private String COMP_PERSON;
    private String alarmEmail;
	private String alarmSMS;
    private String alarmKakao;
    private String recvYn;
    private String grpCd;
    private String apprYn;
    private String manerYn;
    private String delYn;
   	private String regDt;
   	private String regId;
   	private String regIp;
   	private String edtDt;
   	private String edtId;


	public String getSearchTp() {
		return searchTp;
	}
	public void setSearchTp(String searchTp) {
		this.searchTp = searchTp;
	}
	
	public String getAlarmEmail() {
		return alarmEmail;
	}
	public void setAlarmEmail(String alarmEmail) {
		this.alarmEmail = alarmEmail;
	}

	public String getAlarmKakao() {
		return alarmKakao;
	}
	public void setAlarmKakao(String alarmKakao) {
		this.alarmKakao = alarmKakao;
	}
	public String getRecvYn() {
		return recvYn;
	}
	public void setRecvYn(String recvYn) {
		this.recvYn = recvYn;
	}
	public String getGrpCd() {
		return grpCd;
	}
	public void setGrpCd(String grpCd) {
		this.grpCd = grpCd;
	}
	public String getApprYn() {
		return apprYn;
	}
	public void setApprYn(String apprYn) {
		this.apprYn = apprYn;
	}
	public String getManerYn() {
		return manerYn;
	}
	public void setManerYn(String manerYn) {
		this.manerYn = manerYn;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getRegIp() {
		return regIp;
	}
	public void setRegIp(String regIp) {
		this.regIp = regIp;
	}
	public String getEdtDt() {
		return edtDt;
	}
	public void setEdtDt(String edtDt) {
		this.edtDt = edtDt;
	}
	public String getEdtId() {
		return edtId;
	}
	public void setEdtId(String edtId) {
		this.edtId = edtId;
	}
	public String getAlarmSMS() {
		return alarmSMS;
	}
	public void setAlarmSMS(String alarmSMS) {
		this.alarmSMS = alarmSMS;
	}
	public String getMEMBER_ID() {
		return MEMBER_ID;
	}
	public void setMEMBER_ID(String mEMBER_ID) {
		MEMBER_ID = mEMBER_ID;
	}
	public String getMEMBER_PASS() {
		return MEMBER_PASS;
	}
	public void setMEMBER_PASS(String mEMBER_PASS) {
		MEMBER_PASS = mEMBER_PASS;
	}
	public String getMEMBER_EMAIL() {
		return MEMBER_EMAIL;
	}
	public void setMEMBER_EMAIL(String mEMBER_EMAIL) {
		MEMBER_EMAIL = mEMBER_EMAIL;
	}
	public String getMEMBER_TEL() {
		return MEMBER_TEL;
	}
	public void setMEMBER_TEL(String mEMBER_TEL) {
		MEMBER_TEL = mEMBER_TEL;
	}
	public String getMEMBER_NAME() {
		return MEMBER_NAME;
	}
	public void setMEMBER_NAME(String mEMBER_NAME) {
		MEMBER_NAME = mEMBER_NAME;
	}
	
	public String getMEMBER_LANG() {
		return MEMBER_LANG;
	}
	public void setMEMBER_LANG(String mEMBER_LANG) {
		MEMBER_LANG = mEMBER_LANG;
	}
	public String getCdTp() {
		return CdTp;
	}
	public void setCdTp(String cdTp) {
		CdTp = cdTp;
	}
	public String getCOMP_PERSON() {
		return COMP_PERSON;
	}
	public void setCOMP_PERSON(String cOMP_PERSON) {
		COMP_PERSON = cOMP_PERSON;
	}
	public String getMEMBER_PASSWORD() {
		return MEMBER_PASSWORD;
	}
	public void setMEMBER_PASSWORD(String mEMBER_PASSWORD) {
		MEMBER_PASSWORD = mEMBER_PASSWORD;
	}
	public String getMEMBER_CURRENTPWD() {
		return MEMBER_CURRENTPWD;
	}
	public void setMEMBER_CURRENTPWD(String mEMBER_CURRENTPWD) {
		MEMBER_CURRENTPWD = mEMBER_CURRENTPWD;
	}

}