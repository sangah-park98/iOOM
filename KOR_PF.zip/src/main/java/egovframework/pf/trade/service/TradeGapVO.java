package egovframework.pf.trade.service;


public class TradeGapVO {

	
	private String cmpnyCd;
	private String tradeType;
	private String tradeNo;
	private String tradeItemCd;
	private String tradeQty;
	private String tradeRemark;
	private String tradeItemNote;
	
	
	
	private String delYn;
	private String regDt;
	private String regId;
	private String edtDt;
	private String edtId;
	
	
	
	
	public String getTradeNo() {
		return tradeNo;
	}
	public void setTradeNo(String tradeNo) {
		this.tradeNo = tradeNo;
	}
	public String getTradeItemCd() {
		return tradeItemCd;
	}
	public void setTradeItemCd(String tradeItemCd) {
		this.tradeItemCd = tradeItemCd;
	}
	public String getTradeQty() {
		return tradeQty;
	}
	public void setTradeQty(String tradeQty) {
		this.tradeQty = tradeQty;
	}
	public String getCmpnyCd() {
		return cmpnyCd;
	}
	public void setCmpnyCd(String cmpnyCd) {
		this.cmpnyCd = cmpnyCd;
	}
	public String getTradeItemNote() {
		return tradeItemNote;
	}
	public void setTradeItemNote(String tradeItemNote) {
		this.tradeItemNote = tradeItemNote;
	}
	public String getTradeRemark() {
		return tradeRemark;
	}
	public void setTradeRemark(String tradeRemark) {
		this.tradeRemark = tradeRemark;
	}
	public String getTradeType() {
		return tradeType;
	}
	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getEdtDt() {
		return edtDt;
	}
	public void setEdtDt(String edtDt) {
		this.edtDt = edtDt;
	}
	public String getEdtId() {
		return edtId;
	}
	public void setEdtId(String edtId) {
		this.edtId = edtId;
	}
	
	
	
	
}