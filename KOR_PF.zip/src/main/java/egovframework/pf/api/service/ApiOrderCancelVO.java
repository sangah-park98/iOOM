package egovframework.pf.api.service;

public class ApiOrderCancelVO {

	private String mngDeptId;
	private String orderId;
	private String regid;
	
	public String getMngDeptId() {
		return mngDeptId;
	}
	public void setMngDeptId(String mngDeptId) {
		this.mngDeptId = mngDeptId;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getRegid() {
		return regid;
	}
	public void setRegid(String regid) {
		this.regid = regid;
	}
	
}