package egovframework.pf.api.service;

public class ApiEtcChargeVO {

	private String orderId;
	private int sellCharge;
	private int sellChargeAdd;
	private String externalInfomation;
	private String externalNumber;
	
	
	public int getSellChargeAdd() {
		return sellChargeAdd;
	}
	public void setSellChargeAdd(int sellChargeAdd) {
		this.sellChargeAdd = sellChargeAdd;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public int getSellCharge() {
		return sellCharge;
	}
	public void setSellCharge(int sellCharge) {
		this.sellCharge = sellCharge;
	}
	public String getExternalInfomation() {
		return externalInfomation;
	}
	public void setExternalInfomation(String externalInfomation) {
		this.externalInfomation = externalInfomation;
	}
	public String getExternalNumber() {
		return externalNumber;
	}
	public void setExternalNumber(String externalNumber) {
		this.externalNumber = externalNumber;
	}
}