package egovframework.pf.api.service;

			  // 2_5 오더 추가
public class ApiStateOrderAddVO {

	private String mngDeptId;
	private String bizName;
	private String bizNum;
	private String externalInfomation;
	private String externalNumber;
	private String orderId;
	private String eComName;
	private String eAddr;
	private String eAddrDetail;
	private String eDate;
	private String eStaff;
	private String eTel;
	private String eMemo;
	private int sellCharge;
	private int sellChargeAdd;
	
	
	public int getSellChargeAdd() {
		return sellChargeAdd;
	}
	public void setSellChargeAdd(int sellChargeAdd) {
		this.sellChargeAdd = sellChargeAdd;
	}
	public String getMngDeptId() {
		return mngDeptId;
	}
	public void setMngDeptId(String mngDeptId) {
		this.mngDeptId = mngDeptId;
	}
	public String getBizName() {
		return bizName;
	}
	public void setBizName(String bizName) {
		this.bizName = bizName;
	}
	public String getBizNum() {
		return bizNum;
	}
	public void setBizNum(String bizNum) {
		this.bizNum = bizNum;
	}
	public String getExternalInfomation() {
		return externalInfomation;
	}
	public void setExternalInfomation(String externalInfomation) {
		this.externalInfomation = externalInfomation;
	}
	public String getExternalNumber() {
		return externalNumber;
	}
	public void setExternalNumber(String externalNumber) {
		this.externalNumber = externalNumber;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String geteComName() {
		return eComName;
	}
	public void seteComName(String eComName) {
		this.eComName = eComName;
	}
	public String geteAddr() {
		return eAddr;
	}
	public void seteAddr(String eAddr) {
		this.eAddr = eAddr;
	}
	public String geteAddrDetail() {
		return eAddrDetail;
	}
	public void seteAddrDetail(String eAddrDetail) {
		this.eAddrDetail = eAddrDetail;
	}
	public String geteDate() {
		return eDate;
	}
	public void seteDate(String eDate) {
		this.eDate = eDate;
	}
	public String geteStaff() {
		return eStaff;
	}
	public void seteStaff(String eStaff) {
		this.eStaff = eStaff;
	}
	public String geteTel() {
		return eTel;
	}
	public void seteTel(String eTel) {
		this.eTel = eTel;
	}
	public String geteMemo() {
		return eMemo;
	}
	public void seteMemo(String eMemo) {
		this.eMemo = eMemo;
	}
	public int getSellCharge() {
		return sellCharge;
	}
	public void setSellCharge(int sellCharge) {
		this.sellCharge = sellCharge;
	}
	
}