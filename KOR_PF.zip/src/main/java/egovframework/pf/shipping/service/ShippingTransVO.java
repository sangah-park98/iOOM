package egovframework.pf.shipping.service;

public class ShippingTransVO {

	private String seq;
	private String shippingCmpny;
	private String rptNo;
	private String orderId;
	private String transactionType;
	private String transactionDt;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getShippingCmpny() {
		return shippingCmpny;
	}
	public void setShippingCmpny(String shippingCmpny) {
		this.shippingCmpny = shippingCmpny;
	}
	public String getRptNo() {
		return rptNo;
	}
	public void setRptNo(String rptNo) {
		this.rptNo = rptNo;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionDt() {
		return transactionDt;
	}
	public void setTransactionDt(String transactionDt) {
		this.transactionDt = transactionDt;
	}
	
}