package egovframework.ms.item.web;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.annotation.processing.SupportedSourceVersion;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.plaf.synth.SynthSpinnerUI;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import egovframework.pf.cmmn.service.CmmnService;
import egovframework.pf.cmmn.service.SearchVO;
import egovframework.pf.cmmn.service.UserSessionVO;
import egovframework.pf.exp.web.ZipFileDownload;
import egovframework.pf.item.service.ItemCheckedVO;
import egovframework.pf.item.service.pfItemService;
import egovframework.pf.shipping.service.ShippingAddressVO;
import egovframework.pf.shipping.service.ShippingOrderVO;
import egovframework.pf.util.ItemView_ExcelUtil;
import egovframework.rte.psl.dataaccess.util.EgovMap;


@Controller
public class itemController {

	@Resource(name = "CmmnService")
	private CmmnService CmmnService;
	
	@Resource(name = "pfItemService")
	private pfItemService pfitemService;

	@RequestMapping(value = "/item/itemInfo.do")
	public String importView(HttpServletRequest request, Model model) throws Exception {
		HttpSession httpSession = request.getSession(true);
		UserSessionVO userVO = (UserSessionVO) httpSession.getAttribute("USER");
		SearchVO vo = new SearchVO();
		String lang = userVO.getLang();
		vo.setLang(lang);
		vo.setCmpnyCd(userVO.getCmpnyCd());
		vo.setCorpNo(userVO.getCorpNo());
		model.addAttribute("lang", lang);
		model.addAttribute("userCmpnyCd", userVO.getCmpnyCd());
		model.addAttribute("grpCd", userVO.getGrpCd());
		return "item/itemView";
	}
		 
	@RequestMapping(value="/item/selectItemViewList.do")
	public ModelAndView selectItemViewList(@ModelAttribute("searchVO") SearchVO vo, HttpServletRequest request, ModelMap model) throws Exception {
	    HttpSession httpSession = request.getSession(true);
	    UserSessionVO userVO = (UserSessionVO) httpSession.getAttribute("USER");
		vo.setList(userVO.getCorpNos());
	    List<?> resultList = null;
	    if(vo.getExType().equals("01")) {
	    	if(vo.getSrch13()!= null) {
	    		System.out.println("전체,중복O");
	    		// resultList = pfitemService.selectDuplicationItemViewList(vo);
	    	} else {
	    		System.out.println("전체,중복X");
    		    resultList = pfitemService.selectItemViewList(vo);
	    	}
	    } else if(vo.getExType().equals("02")) {
	    	if(vo.getSrch13()!= null) {
	    		System.out.println("수입,중복O"); 
	    		 // resultList = pfitemService.selectDuplicationItemViewImpList(vo);
	    	} else {
	    		System.out.println("수입,중복X");
	    		resultList = pfitemService.selectItemViewImpList(vo);
	    	}
	    } else if(vo.getExType().equals("03")) {
	    	if(vo.getSrch13()!= null) {
	    		System.out.println("수출,중복O"); 
				// resultList = pfitemService.selectDuplicationItemViewExpList(vo);
	    	} else {
	    		System.out.println("수출,중복X");   
				resultList = pfitemService.selectItemViewExpList(vo);
	    	}
				
	    }
	    ModelAndView mav = new ModelAndView("jsonView");
	    mav.addObject("resultList", resultList);
	    return mav;
	}
		
	@RequestMapping(value = "/item/selectItemCodeChkList.do")
	public ModelAndView selectItemCodeChkList(@ModelAttribute("searchVO") SearchVO vo, HttpServletRequest request, ModelMap model) throws Exception {
		HttpSession httpSession = request.getSession(true);
		UserSessionVO userVO = (UserSessionVO) httpSession.getAttribute("USER");
		vo.setList(userVO.getCorpNos());
		List<?> resultList = pfitemService.selectItemCodeChkList(vo);
		model.addAttribute("resultList", resultList);
		ModelAndView mav = new ModelAndView("jsonView", model);
		return mav;
	}
	
	@RequestMapping(value = "/item/insertItemChkedList.do")
	@ResponseBody
	public Map<String, String> insertItemChkedList(@RequestBody List<ItemCheckedVO> ivoList, HttpServletRequest request, ModelMap model) throws Exception {
	    HttpSession httpSession = request.getSession(true);
	    UserSessionVO userVO = (UserSessionVO) httpSession.getAttribute("USER");
	    
	    for (ItemCheckedVO ivo : ivoList) {
	        Map<String, Object> map = new HashMap<>();
	        map.put("itemCode", ivo.getItemCode());
	        map.put("itemStatus", ivo.getItemStatus());
	        map.put("excGname", ivo.getExcGname());
	        map.put("itemDesc", ivo.getItemDesc());
	        map.put("currency", ivo.getCurrency());
	        map.put("hs", ivo.getHs());
	        map.put("memo", ivo.getMemo());
	        ivo.setCmpnyCd(userVO.getCorpNo());
	        ivo.setRegId(userVO.getId());
	        
	        pfitemService.insertItemChkedList(ivo);
	    }
	    Map<String, String> response = new HashMap<>();
	    response.put("status", "success");
	    return response;
	}
	
	@RequestMapping(value = "/item/selectItemCodeMemoList.do")
	public ModelAndView selectItemCodeMemoList(@ModelAttribute("searchVO") SearchVO vo, HttpServletRequest request, 
			ModelMap model) throws Exception {
		HttpSession httpSession = request.getSession(true);
		UserSessionVO userVO = (UserSessionVO) httpSession.getAttribute("USER");
		if(!userVO.getCorpNo().equals("00000000000")) {
			vo.setCorpNo(userVO.getCorpNo());
		}
		List<?> resultList = pfitemService.selectItemCodeMemoList(vo);
		model.addAttribute("resultList", resultList);
		ModelAndView mav = new ModelAndView("jsonView", model);
		return mav;
	}
	
	@RequestMapping(value = "/item/updateItemMemoList.do")
	@ResponseBody
	public Map<String, String> updateItemMemoList(@RequestBody List<ItemCheckedVO> ivoList, HttpServletRequest request, ModelMap model) throws Exception {
	    HttpSession httpSession = request.getSession(true);
	    UserSessionVO userVO = (UserSessionVO) httpSession.getAttribute("USER");
	    List<String> corpNos = userVO.getCorpNos(); 
	    
	    for (ItemCheckedVO ivo : ivoList) {
	        Map<String, Object> map = new HashMap<>();
	        map.put("itemCode", ivo.getItemCode());
	        map.put("memo", ivo.getMemo());
	        map.put("hs", ivo.getHs());
	        map.put("currency", ivo.getCurrency());
	        
	        ivo.setRegId(userVO.getId());
	        ivo.setList(corpNos);
	        pfitemService.updateItemMemoList(ivo);
	    }
	    Map<String, String> response = new HashMap<>();
	    response.put("status", "success");
	    return response;
	}
	
	@RequestMapping(value = "/item/deleteItemMemoList.do", method = RequestMethod.POST)
	@ResponseBody
	public void deleteItemMemoList(@RequestBody List<ItemCheckedVO> ivoList, HttpServletRequest request, ModelMap model) throws Exception {
	    HttpSession httpSession = request.getSession(true);
	    UserSessionVO userVO = (UserSessionVO) httpSession.getAttribute("USER");
	    List<String> corpNos = userVO.getCorpNos();
	    
        for (ItemCheckedVO ivo : ivoList) {
        	ivo.setList(corpNos);
        	ivo.setRegId(userVO.getId());
            pfitemService.deleteItemMemoList(ivo);
        }
	}
	
	@RequestMapping(value="/item/selectItemHsCodeDiffList.do", method = RequestMethod.POST)
	public ModelAndView selectItemHsCodeDiffList(@ModelAttribute("searchVO") SearchVO vo, HttpServletRequest request, ModelMap model) throws Exception {
	    HttpSession httpSession = request.getSession(true);
	    UserSessionVO userVO = (UserSessionVO) httpSession.getAttribute("USER");
		vo.setList(userVO.getCorpNos());
	    List<?> resultList = null;
	    
	    if(vo.getExType().equals("01")) {
	    	System.out.println("전체: 세번적용내역"); 
	    	resultList = pfitemService.selectItemHsCodeDiffList(vo);
	    	for(Object obj : resultList) {
		    	EgovMap map = (EgovMap)obj;
		    	SearchVO subVo = new SearchVO();
		    	List<?> subResultList = null;
		    	
		    	subVo.setList(userVO.getCorpNos());
		    	subVo.setExType(vo.getExType());
		    	subVo.setSrch1(vo.getSrch1());
		    	subVo.setSrch2(vo.getSrch2());
		        subVo.setSrch3(vo.getSrch3());
		        subVo.setSrch10(vo.getSrch10());
		    	subVo.setSrch4((String)map.get("hs"));
		    	subVo.setSrch5((String)map.get("goodsName"));
		    	
		    	subResultList = pfitemService.selectItemHsCodeDiffSubList(subVo);
		    	map.put("__children", subResultList);
		    }
	    } else if(vo.getExType().equals("02")) {
	    	System.out.println("수입: 세번적용내역");
	    	resultList = pfitemService.selectItemHsCodeDiffImpList(vo);
	    	for(Object obj : resultList) {
		    	EgovMap map = (EgovMap)obj;
		    	SearchVO subVo = new SearchVO();
		    	List<?> subResultList = null;
		    	
		    	subVo.setList(userVO.getCorpNos());
		    	subVo.setExType(vo.getExType());
		    	subVo.setSrch1(vo.getSrch1());
		    	subVo.setSrch2((String)map.get("hs"));
		    	
		    	subResultList = pfitemService.selectItemHsCodeDiffImpSubList(subVo);
		    	map.put("__children", subResultList);
		    }
	    } else {
	    	System.out.println("수출: 세번적용내역");
	    	resultList = pfitemService.selectItemHsCodeDiffExpList(vo);
	    	for(Object obj : resultList) {
		    	EgovMap map = (EgovMap)obj;
		    	SearchVO subVo = new SearchVO();
		    	List<?> subResultList = null;
		    	
		    	subVo.setList(userVO.getCorpNos());
		    	subVo.setExType(vo.getExType());
		    	subVo.setSrch1(vo.getSrch1());
		    	subVo.setSrch2((String)map.get("hs"));
		    	
		    	subResultList = pfitemService.selectItemHsCodeDiffExpSubList(subVo);
		    	map.put("__children", subResultList);
		    }
	    }
				
	    ModelAndView mav = new ModelAndView("jsonView");
	    mav.addObject("resultList", resultList);
	    return mav;
	}
	
	@RequestMapping(value = "/item/selectItemPriceList.do")
	public ModelAndView selectItemPriceList(@ModelAttribute("searchVO") SearchVO vo, HttpServletRequest request, ModelMap model) throws Exception {
		HttpSession httpSession = request.getSession(true);
		UserSessionVO userVO = (UserSessionVO) httpSession.getAttribute("USER");
		vo.setList(userVO.getCorpNos());
		List<?> resultList = pfitemService.selectItemPriceList(vo);
		model.addAttribute("resultList", resultList);
		ModelAndView mav = new ModelAndView("jsonView", model);
		return mav;
	}
	
	@RequestMapping(value = "/item/selectItemOutOfRateList.do")
	public ModelAndView selectItemOutOfRateList(@ModelAttribute("searchVO") SearchVO vo, HttpServletRequest request, ModelMap model) throws Exception {
		HttpSession httpSession = request.getSession(true);
		UserSessionVO userVO = (UserSessionVO) httpSession.getAttribute("USER");
		vo.setList(userVO.getCorpNos());
		List<?> resultList = null;
	    
	    if(vo.getExType().equals("01")) {
	    	resultList = pfitemService.selectItemOutOfRateList(vo);
	    } else if(vo.getExType().equals("02")) {
	    	resultList = pfitemService.selectItemOutOfRateImpList(vo);
	    } else {
	    	resultList = pfitemService.selectItemOutOfRateExpList(vo);
	    }
		model.addAttribute("resultList", resultList);
		ModelAndView mav = new ModelAndView("jsonView", model);
		return mav;
	}
	
	@RequestMapping(value = "/item/selectItemRptNoList.do")
	public ModelAndView selectItemRptNoList(@ModelAttribute("searchVO") SearchVO vo, HttpServletRequest request, ModelMap model) throws Exception {
		HttpSession httpSession = request.getSession(true);
		UserSessionVO userVO = (UserSessionVO) httpSession.getAttribute("USER");
		vo.setList(userVO.getCorpNos());
		List<?> resultList = null;
	    
	    if(vo.getExType().equals("01")) {
	    	resultList = pfitemService.selectItemRptNoList(vo);
	    } else if(vo.getExType().equals("02")) {
	    	resultList = pfitemService.selectItemRptNoImpList(vo);
	    } else {
	    	resultList = pfitemService.selectItemRptNoExpList(vo);
	    }
		model.addAttribute("resultList", resultList);
		ModelAndView mav = new ModelAndView("jsonView", model);
		return mav;
	}
	
	@RequestMapping(value="/item/selectItemLawCdList.do", method = RequestMethod.POST)
	public ModelAndView selectItemLawCdList(@ModelAttribute("searchVO") SearchVO vo, HttpServletRequest request, ModelMap model) throws Exception {
	    HttpSession httpSession = request.getSession(true);
	    UserSessionVO userVO = (UserSessionVO) httpSession.getAttribute("USER");
		vo.setList(userVO.getCorpNos());
		List<?> resultList = null;
		
    	if(vo.getExType().equals("01")) {
    		resultList = pfitemService.selectItemLawCdList(vo);
    		
	    	/*for(Object obj : resultList) {
		    	EgovMap map = (EgovMap)obj;
		    	SearchVO subVo = new SearchVO();
		    	List<?> subResultList = null;
		    	
		    	subVo.setList(userVO.getCorpNos());
		    	subVo.setExType(vo.getExType());
		    	subVo.setSrch1(vo.getSrch1());
		    	subVo.setSrch2((String)map.get("hs"));
		    	
		    	subResultList = pfitemService.selectItemHsCodeDiffSubList(subVo);
		    	map.put("__children", subResultList);
		    }*/
    	} else if(vo.getExType().equals("02")) {
	    	/*System.out.println("수입: 세번적용내역");
	    	resultList = pfitemService.selectItemHsCodeDiffImpList(vo);
	    	for(Object obj : resultList) {
		    	EgovMap map = (EgovMap)obj;
		    	SearchVO subVo = new SearchVO();
		    	List<?> subResultList = null;
		    	
		    	subVo.setList(userVO.getCorpNos());
		    	subVo.setExType(vo.getExType());
		    	subVo.setSrch1(vo.getSrch1());
		    	subVo.setSrch2((String)map.get("hs"));
		    	
		    	subResultList = pfitemService.selectItemHsCodeDiffImpSubList(subVo);
		    	map.put("__children", subResultList);
		    }*/
	    } else {
	    	/*System.out.println("수출: 세번적용내역");
	    	resultList = pfitemService.selectItemHsCodeDiffExpList(vo);
	    	for(Object obj : resultList) {
		    	EgovMap map = (EgovMap)obj;
		    	SearchVO subVo = new SearchVO();
		    	List<?> subResultList = null;
		    	
		    	subVo.setList(userVO.getCorpNos());
		    	subVo.setExType(vo.getExType());
		    	subVo.setSrch1(vo.getSrch1());
		    	subVo.setSrch2((String)map.get("hs"));
		    	
		    	subResultList = pfitemService.selectItemHsCodeDiffExpSubList(subVo);
		    	map.put("__children", subResultList);
		    }*/
	
	    }

	    ModelAndView mav = new ModelAndView("jsonView");
	    mav.addObject("resultList", resultList);
	    return mav;
	}
	
	/*@RequestMapping(value="/item/selectItemLawCdList.do", method = RequestMethod.POST)
	public ModelAndView selectItemLawCdList(@ModelAttribute("searchVO") SearchVO vo, HttpServletRequest request, ModelMap model) throws Exception {
	    HttpSession httpSession = request.getSession(true);
	    UserSessionVO userVO = (UserSessionVO) httpSession.getAttribute("USER");
		vo.setList(userVO.getCorpNos());
		List<Object> resultList = new ArrayList<>();
		List<Map<String, String>> hsList = pfitemService.selectHsList(vo);
		
    	if(vo.getExType().equals("01")) {
    		for (Map<String, String> hsMap : hsList) {
    	        String hs = hsMap.get("hs");
    			vo.setSrch2(hs);
    			System.out.println("vo.getSrch2(): " + vo.getSrch2());
    			List<?> tempList = pfitemService.selectItemLawCdList(vo);
                resultList.addAll(tempList);
    		}
    		System.out.println("resultList: " + resultList);
    		
	    	for(Object obj : resultList) {
		    	EgovMap map = (EgovMap)obj;
		    	SearchVO subVo = new SearchVO();
		    	List<?> subResultList = null;
		    	
		    	subVo.setList(userVO.getCorpNos());
		    	subVo.setExType(vo.getExType());
		    	subVo.setSrch1(vo.getSrch1());
		    	subVo.setSrch2((String)map.get("hs"));
		    	
		    	subResultList = pfitemService.selectItemHsCodeDiffSubList(subVo);
		    	map.put("__children", subResultList);
		    }
	    } else if(vo.getExType().equals("02")) {
	    	System.out.println("수입: 세번적용내역");
	    	resultList = pfitemService.selectItemHsCodeDiffImpList(vo);
	    	for(Object obj : resultList) {
		    	EgovMap map = (EgovMap)obj;
		    	SearchVO subVo = new SearchVO();
		    	List<?> subResultList = null;
		    	
		    	subVo.setList(userVO.getCorpNos());
		    	subVo.setExType(vo.getExType());
		    	subVo.setSrch1(vo.getSrch1());
		    	subVo.setSrch2((String)map.get("hs"));
		    	
		    	subResultList = pfitemService.selectItemHsCodeDiffImpSubList(subVo);
		    	map.put("__children", subResultList);
		    }
	    } else {
	    	System.out.println("수출: 세번적용내역");
	    	resultList = pfitemService.selectItemHsCodeDiffExpList(vo);
	    	for(Object obj : resultList) {
		    	EgovMap map = (EgovMap)obj;
		    	SearchVO subVo = new SearchVO();
		    	List<?> subResultList = null;
		    	
		    	subVo.setList(userVO.getCorpNos());
		    	subVo.setExType(vo.getExType());
		    	subVo.setSrch1(vo.getSrch1());
		    	subVo.setSrch2((String)map.get("hs"));
		    	
		    	subResultList = pfitemService.selectItemHsCodeDiffExpSubList(subVo);
		    	map.put("__children", subResultList);
		    }
	
	    }

	    ModelAndView mav = new ModelAndView("jsonView");
	    mav.addObject("resultList", resultList);
	    return mav;
	}*/

	// 엑셀
	@RequestMapping(value="/item/downloadExcel.do")
	public ModelAndView downloadExcel(@ModelAttribute("searchVO") SearchVO vo, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
	HttpSession httpSession = request.getSession(true);
	UserSessionVO userVO = (UserSessionVO) httpSession.getAttribute("USER");
	vo.setList(userVO.getCorpNos());
	vo.setRecordCountPerPage(99999999);
	vo.setStartPage(0);
	ModelAndView mv = new ModelAndView("jsonView");
	String resultCode="200";
	XSSFSheet sheet;

	try {
		ModelAndView dataMv = new ModelAndView();
		List<Object> resultList1 = new ArrayList<>();
        List<Object> resultList2 = new ArrayList<>();
        List<Object> resultList3 = new ArrayList<>();
        List<Object> resultList4 = new ArrayList<>();
    
		XSSFWorkbook workBook = new XSSFWorkbook();
		String[] colUnion = {};
		String[] haedUnion =  {};
		List<String> divUnion = new ArrayList<>();
		int unionIdx = 0;
		System.out.println("vo.getExTitDiv()"+vo.getExTitDiv());
		
		colUnion = vo.getExCol().split("\\|\\|\\|");
		haedUnion = vo.getExTit().split("\\|\\|\\|\\|");
		//divUnion = vo.getExTitDiv().split("\\|\\|", -1);
		// JSON 형식의 문자열을 리스트로 변환
        ObjectMapper mapper = new ObjectMapper();
        divUnion = mapper.readValue(URLDecoder.decode(vo.getExTitDiv(), "UTF-8"), new TypeReference<List<String>>(){});
        
        
		 System.out.println("colUnion: " + Arrays.toString(colUnion));
	     System.out.println("headUnion: " + Arrays.toString(haedUnion));
	     System.out.println("divUnion: " + divUnion);
	     
	     System.out.println("colUnion0: " + colUnion[0]);
	     //System.out.println("colUnion1: " + colUnion[1]);
		            
		
	     SearchVO sheetSearchVo = new SearchVO();
	     sheetSearchVo.setLang(userVO.getLang());      
	     sheetSearchVo.setCorpNo(userVO.getCorpNo());
	     sheetSearchVo.setRecordCountPerPage(99999999);
	     sheetSearchVo.setStartPage(0);
		
	     System.out.println("setSrch13"+vo.getSrch13());
	     // item 정보 
	
	     dataMv = this.selectItemViewList(vo, request, new ModelMap());
	     List<Object> tempResultList1 = (List<Object>) dataMv.getModel().get("resultList");
	     resultList1.addAll(tempResultList1);
		
	     System.out.println("resultList아이템정보"+resultList1);
	     ArrayList<String> conts = new ArrayList<String>();
	     conts.add("1");
	     sheet = ItemView_ExcelUtil.createSheetWithTitleRow(workBook, "item정보", colUnion[0].split("\\|\\|").length);
	     sheet = ItemView_ExcelUtil.createSummaryCont(sheet, conts);
	     sheetSearchVo.setExCol(colUnion[0]);
	     sheetSearchVo.setExTit(haedUnion[0]);
	     sheet = ItemView_ExcelUtil.createMainTable(sheet, resultList1, sheetSearchVo);
	     int cnt = 0;
	     String ExcelTitle = "";
	     if(userVO.getCorpNos().size() > 1) {
			cnt = userVO.getCorpNos().size() - 1;
			ExcelTitle = userVO.getCmpnyCd() + " 외 " + cnt + "개";
	     } else {
			ExcelTitle = userVO.getCmpnyCd();
	     }
	     ItemView_ExcelUtil.generateExcelFile(workBook, ExcelTitle.concat(" ").concat("ITEM정보".replace("_", " ")), response);
	     
	} catch (Exception e) {
		e.printStackTrace();
	}
		
	mv.addObject("resultCode", resultCode);
	return mv;
	}
}	