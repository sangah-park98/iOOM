import "./modulepreload-polyfill.js";
/* empty css      */
import { l as library$1, f as faUser, a as faLockKeyhole, b as faPhoneVolume, c as faEnvelopes, m as dom$1 } from "./vendor.js";
library$1.add(faUser, faLockKeyhole, faPhoneVolume, faEnvelopes);
dom$1.watch();
