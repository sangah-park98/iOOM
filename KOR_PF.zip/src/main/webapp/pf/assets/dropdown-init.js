import { i as initDropdowns } from "./vendor.js";
initDropdowns();
